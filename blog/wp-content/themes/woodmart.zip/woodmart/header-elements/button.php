<?php
woodmart_enqueue_inline_style( 'header-elements-base' );
echo woodmart_shortcode_button($params);
